#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void func(int b[5][5]) {
	int a[5][5], i, j;
	for (i = 0; i < 5; ++i) {
		for (j = 0; j < 5; ++j)
		{
			a[i][j] = b[4-j][i];
		}
	}
	printf("\nresult:\n");
	for (i = 0; i < 5; ++i) {
		for (j = 0; j < 5; ++j)
		{
			printf("%8d", a[i][j]);
			if (j == 4)
			{
				printf("\n");
			}
		}
	}
}

int main()
{
	int i,j;
	int mat[5][5];
	srand(time(NULL));
	for (i = 0; i < 5; ++i) {
		for (j = 0; j < 5;++j)
		{
			mat[i][j] = rand();
		}
	}
	printf("matrix:\n");
	for (i = 0; i < 5; ++i) {
		for (j = 0; j < 5; ++j) 
		{
			printf("%8d", mat[i][j]);
			if (j == 4)
			{
				printf("\n");
			}
		}
	}
	func(mat);
}