#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void matsum(int arr1[5][6], int arr2[5][6])
{
	int a, b, sum[5][6];
	for (a = 0; a < 5; a++)
		for (b = 0; b < 6; b++)
		{
			sum[a][b] = arr2[a][b] + arr1[a][b];
		}
	printf("matrix1:\n");
	for (a = 0; a < 5; a++)
		for (b = 0; b < 6; b++)
		{
			printf("%5d", arr1[a][b]);
			if (b == 5)
				printf("\n");
		}
	printf("matrix2:\n");
	for (a = 0; a < 5; a++)
		for (b = 0; b < 6; b++)
		{
			printf("%5d", arr2[a][b]);
			if (b == 5)
				printf("\n");
		}
	printf("result:\n");
	for (a = 0; a < 5; a++)
		for (b = 0; b < 6; b++)
		{
			printf("%5d", sum[a][b]);
			if (b == 5)
				printf("\n");
		}
}

int main()
{
	int arr1[5][6];
	int arr2[5][6];
	int a, b;
	srand((unsigned)time(NULL));
	for (a = 0; a < 5; a++)
		for (b = 0; b < 6; b++)
		{
			arr1[a][b] = rand() % 100 + 1;
		}
	for (a = 0; a < 5; a++)
		for (b = 0; b < 6; b++)
		{
			arr2[a][b] = rand() % 100 + 1;
		}
	matsum(arr1, arr2);
	
	
}

