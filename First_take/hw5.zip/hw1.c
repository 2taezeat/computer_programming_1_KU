#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	int array[21];
	int i=0,j=0,k;
	srand(time(NULL));
	printf("Nonrepetitive array values are:\n");
	for (i = 0; i<20;i++ )
	{
		array[j] = rand() % 20 + 1;
		for (k = 0; k < j;++k)
		{
			if (array[j] == array[k]) {
				--j;
			}
		
		}
		++j;
	}
	array[j + 1] = 0;
	for (i = 0; array[i] != 0;++i)
	{
		printf("Array[ %d ] = %2d\n", i, array[i]);
	}
}