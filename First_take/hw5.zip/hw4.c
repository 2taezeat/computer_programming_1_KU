#include <stdio.h>

void stringReverse(char a[],int b)
{
	if (b < 0)
		return 0;
	--b;
	printf("%c", a[b]);
	stringReverse(a, b);
	
}

int main()
{
	int size;
	char strArray[] = "Print this string backward.";
	printf("Print this string backward.\n");
	size = sizeof(strArray) / sizeof(char);
	stringReverse( strArray,size-1 );
}