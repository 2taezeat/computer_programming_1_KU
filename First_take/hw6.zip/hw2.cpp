#include <stdio.h>

int func(char string1[], char string2[])
{
	for (int i = 0; i < 80; i++)
	{
		if (string1[i] != string2[i])
			return 0;
	}
	return 1;
}

int main()
{
	char string1[80], string2[80];
	printf("Enter the strings: ");
	scanf("%s%s", string1, string2);
	if (func(string1, string2))
	{
		printf("%s and %s are equal.\n", string1, string2);
	}
	else
	{
		printf("%s and %s are not equal.\n", string1, string2);
	}
}