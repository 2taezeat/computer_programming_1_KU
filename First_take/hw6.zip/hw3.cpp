#include <stdio.h>

int main()
{
	int i,j,k;
	char string1[80], string2[80];
	printf("Enter two strings: ");
	scanf("%s%s", string1, string2);
	for (i = 0; string1[i] != 0; i++)
	{
	}
	for (j=0; string2[j] != 0; j++)
	{
		string1[i] = string2[j];
		i++;
	}
	k = i;
	for (i = 0; i<k; i++)
	{
		printf("%c", string1[i]);
	}
	printf("\n");
}