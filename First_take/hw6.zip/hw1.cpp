#include <stdio.h>

int func(int* a, int* b, int* c)
{
	int n;
	*a += 1;
	n = *b**c;
	*b = *c;
	*c = n;
	return a, b, c;

}

int main()
{
	int q, w, e;
	int* a, *b, *c;
	printf("Enter three numbers: ");
	scanf("%d%d%d", &q, &w, &e);
	printf("Before: a = %d, b = %d, c = %d\n", q, w, e);
	a = &q; b = &w; c = &e;
	func(a, b, c);
	printf("After: a = %d, b = %d, c = %d\n", *a, *b, *c);
}