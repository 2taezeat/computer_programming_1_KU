#include <stdio.h>

int add(int a, int b)
{
	int n = a + b;
	return n;
}

int sub(int a, int b)
{
	int n = a - b;
	return n;
}

int mul(int a, int b)
{
	int n = a * b;
	return n;
}

int main()
{
	int select,a,b;
	int(*func[3])(int, int) = { add,sub,mul };
	printf("0.Addition\n1.Subtraction\n2.Multiplication\n3.End\nselect the operation: ");
	scanf("%d", &select);
	printf("Enter the two numbers: ");
	scanf("%d%d", &a, &b);
	switch(select)
	{
	case 0:
		printf("%d + %d = %d\n", a, b, func[0](a, b));
		break;
	case 1:
		printf("%d - %d = %d\n", a, b, func[1](a, b));
		break;
	case 2:
		printf("%d * %d = %d\n", a, b, func[2](a, b));
		break;
	}
}