#include <stdio.h>
int main(void)
{
	printf("Decimal		Binary\n");
	int a1, a2, a3;
	for (a1 = 0; a1 < 16;a1++)
	{   printf("%d\t\t", a1);
		
	printf("%d%d%d%d\n", (a1 % 16 >= 7) ? 1 : 0, (a1 % 8 >= 3) ? 1 : 0, (a1 % 4 >= 1) ? 1 : 0, (a1 % 2 == 1) ? 1 : 0);

	}

	return 0;
}