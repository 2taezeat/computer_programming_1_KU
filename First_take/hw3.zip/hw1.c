#include <stdio.h>

int main(void)
{
	int a1, a2 = 0, a3;
	printf("Enter the number: ");
	scanf("%d", &a1);
	a3 = a1;
	do
	{
		printf("Enter the number: ");
		scanf("%d", &a1);
		if (a1 >= a3) { a3 = a1; }
		else { a3 = a3; }
		a2++;
	} while (a2 != 4);
	printf("Largest is %d", a3);
	return 0;
}