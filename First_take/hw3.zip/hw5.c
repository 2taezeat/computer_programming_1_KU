#include <stdio.h>
int main(void)
{
	double pi = 0.0;
	double num = 4.0;
	double denom = 1.0;
	long int loop;
	long int accuracy;

	accuracy = 900000;

	printf("Accuracy set a: %d\n", accuracy);
	printf("term\t\t pi\n");
	
	int a1=-1;
	for (loop = 1; loop <= accuracy; loop++)
	{
		a1 = a1*(-1);
		pi = pi + a1 * 4 / (2 * (float)loop - 1);
		if (loop % 50000 == 0)
		{
			printf("%d\t\t %f\n", loop, pi);

		}
	}




	return 0;


  }