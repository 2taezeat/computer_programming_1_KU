#include <stdio.h>

int main(void)
{
	int a1, a2, a3, result = 1;
	
	printf("Enter the base number: ");
	scanf("%d", &a1);
	printf("Enter the exponent number: ");
	scanf("%d", &a2);

	while (a1 < 0 || a2 < 0)
	{
		printf("Enter the base number: ");
		scanf("%d", &a1);
		printf("Enter the exponent number: ");
		scanf("%d", &a2);
	}
	for (int a3 = 0; a3 < a2; a3++)
	{
		result *= a1;

	}
	printf("%d^%d is %d", a1, a2, result);
	return 0;
}