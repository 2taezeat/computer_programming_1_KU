#include <stdio.h>
#include <math.h>

double hypotenuse(double a, double b);

int main(void)
{
	double a, b;
	printf("Enter the sides of the triangle : ");
	scanf("%lf %lf", &a, &b);
	printf("Hypotenuse : %.1f", hypotenuse(a, b));

	return 0;
}

double hypotenuse(double a, double b) 
{
	double x = sqrt(a*a + b*b);
	return x;
}