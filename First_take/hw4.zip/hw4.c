#include<stdio.h>
#include<math.h>

int reverse(int a);

int main(void) {
	int input;
	printf("Enter a number between 1 and 9999: ");
	scanf("%d", &input);

	printf("The number with its digits reversed is: %d\n", reverse(input));

	return 0;
}

int reverse(int a)
{
	int i, j, k, l;
	i = a / 1000;
	j = (a - (i * 1000)) / 100;
	k = (a - (i * 1000) - (j * 100)) / 10;
	l = (a - (i * 1000) - (j * 100) - (k * 10));
	int x = i + j * 10 + k * 100 + l * 1000;
	return x;
}

	