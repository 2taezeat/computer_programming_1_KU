#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
	srand((unsigned)time(NULL));
	int n1 = 1;
	int n2;
	int a1 = 0, a2 = 0;
	while (n1<101)
	{


		if (rand() % 2 == 1) 
		{ printf("Tails "); 
		a1++;
		}
		else
		{
			printf("Heads ");
			a2++;
		}
		if (n1 % 10 == 0)
			printf("\n");
		++n1;
	}
	printf("\nThe total number of Heads was %d\n", a1);
	printf("The total number of Tails was %d\n", a2);
}