#include <stdio.h>
void hanoi(int, char, char, char);

int main()
{
	int n;

	printf("Enter the starting number of disks:");
	scanf("%d", &n);
	while (n < 1)
	{
		printf("Enter the starting number of disks:");
		scanf("%d", &n);
	}
	hanoi(n, '1', '2', '3');
}

void hanoi(int n, char a, char b, char c) {


	if (n == 1)
		printf("%c-->%c\n", a, c);
	else
	{
		hanoi(n - 1, a, c, b);
		printf("%c-->%c\n", a, c);
		hanoi(n - 1, b, a, c);

	}
}


