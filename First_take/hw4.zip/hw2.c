#include <stdio.h>
#include <math.h>

void isPerfect(int a);

int main(void) {
	printf("For the integers from 1 to 1000\n");
	
	int i;

	for (i = 1; i <= 1000; i++)
	{

		
		isPerfect(i);
	}
	


	return 0;
}

void isPerfect(int a) 
{
	
	int i = 1, sum = 0;

	for (; i < a; i++) {
		if (a%i == 0)
			sum += i;

	}

	if (sum == a) printf("%d is perfect\n", sum);


	return;


}