#include <stdio.h>

char ulcase(char);
int main()
{
	char n1;
	int n2;
	printf("Enter the character: ");
	scanf("%c", &n1);
	if (ulcase(n1))
		printf("%c:uppercase", n1);
	else
		printf("%c:lowercase", n1);
	return 0;
}
char ulcase(char n1) {
	if (65 <= n1&&n1 <= 90)
		return 1;
	if (97 <= n1 && n1 <= 122)
		return 0;

}