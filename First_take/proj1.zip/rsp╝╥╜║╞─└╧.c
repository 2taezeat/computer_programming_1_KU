#include <stdio.h>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>

void rsp(int);
int vs(char);
int sel = 0, money = 1000000, win = 0, lose = 0, bet = 0, com = 0;
char com1, input,copy;
int main()
{
	while (sel != 3)
	{
		printf("\t--------------------------\n");
		printf("\t\t1. My State\n");
		printf("\t\t2. RSP\n");
		printf("\t\t3. End\n");
		printf("\t--------------------------\n");
		printf("\t\tEnter the number:");
		scanf("%d", &sel);
		rsp(sel);
	}

}
void rsp(int n) {
	int restart = 0, replay = 1;
	srand((unsigned int)time(NULL));
	switch (n)
	{
	case 1:
		system("cls");
		printf("\t--------------------------\n");
		printf("\t\tUser's State\n");
		printf("\t\tCash: %d won\n", money);
		printf("\t\tWin: %d \n", win);
		printf("\t\tLose: %d \n", lose);
		printf("\t--------------------------\n");
		printf("\t\tPlease Enter any key to return");
		if (getch())
			system("cls");
		break;

	case 2:
		system("cls");
		printf("\t--------------------------\n");
		printf("\t\tRock Scissors Paper\n");
		printf("\t--------------------------\n");
		printf("\t\tCash: %d\n", money);
		printf("\t\tHow much do you want to bet?\n\t:");
		scanf("%d", &bet);
		printf("\tOK\n\t..then Now start!");
		Sleep(2000);
		system("cls");
		while (replay) {
			input = 't';
			printf("\t--------------------------\n");
			printf("\t\tRock Scissors Paper\n\n");
			printf("\t\tStart?\n");
			printf("\t--------------------------");
			if (getch())
			{
				if (_kbhit()) {
					input = getch();
				}

				printf("\n\t\t3...\n"); Sleep(1000);
				if (_kbhit()) {
					input = getch();
				}

				printf("\t\t2..\n"); Sleep(1000);
				if (_kbhit()) {
					input = getch();
				}

				printf("\t\t1.\n"); Sleep(1000);
				if (_kbhit()) {
					input = getch();
				}

				printf("\t\trock,"); Sleep(500);
				if (_kbhit()) {
					input = getch();
				}
				printf(" scissors,"); Sleep(500);
				if (_kbhit()) {
					input = getch();
				}
				printf(" paper!,"); Sleep(500);
				if (_kbhit()) {
					input = getch();
				}
			}
			if (input == 't')
			{
				++lose;
				money -= bet;
				printf("\n\n\t\tDo not Enter any key");
				printf("\n\t\tLose!");
				printf("\n\t\t-%d", bet);
				printf("\n\t\tCash: %d", money);
				printf("\n\t\t1.yes");
				printf("\n\t\t2.no\n");
				scanf("%d", &restart);
				if (restart == 1)
					replay = 1;
				else
				{
					replay = 0;
					system("cls");
				}
			}
			else {
				if (vs(input))
				{
					++win;
					money += bet;
					printf("\n\n\t\tUser: %c", copy);
					printf("\tCom: %c", com1);
					printf("\n\t\tWin!");
					printf("\n\t\t+%d", bet);
					printf("\n\n\t\tCash: %d", money);
					printf("\n\t\tOne more?");
					printf("\n\t\t1.yes");
					printf("\n\t\t2.no\n");
					scanf("%d", &restart);
					if (restart == 1)
						replay = 1;
					else
					{
						replay = 0;
						system("cls");
					}
				}
				else
				{
					if (copy == com1)
					{
						printf("\n\n\t\tUser: %c", copy);
						printf("\tCom: %c", com1);
						printf("\n\t\tDraw!");
						printf("\n\t\tRestart\n");
						replay = 1;
					}
					else {
						++lose;
						money -= bet;
						printf("\n\n\t\tUser: %c", copy);
						printf("\tCom: %c", com1);
						printf("\n\t\tLose!");
						printf("\n\t\t-%d", bet);
						printf("\n\n\t\tCash: %d", money);
						printf("\n\t\tOne more?");
						printf("\n\t\t1.yes");
						printf("\n\t\t2.no\n");
						scanf("%d", &restart);
						if (restart == 1)
							replay = 1;
						else
						{
							replay = 0;
							system("cls");
						}
					}

				}
			}
		}
		break;

	case 3:
		system("cls");
		printf("bye\n");
		exit(0);
		break;
	}
}





int vs(char i) {
	com = rand() % 3;          
	if (com == 0) com1 = 'R';
	if (com == 1) com1 = 'S';
	if (com == 2) com1 = 'P';
	switch (com) {
	case 0:
		if (i == 'q')
		{
			copy = 'R';
			return 0;
		}
		if (i == 'w')
		{
			copy = 'S';
			return 0;
		}
		if (i == 'e')
		{
			copy = 'P';
			return 1;
		}
		break;
	case 1:
		if (i == 'q')
		{
			copy = 'R';
			return 1;
		}
		if (i == 'w')
		{
			copy = 'S';
			return 0;
		}
		if (i == 'e')
		{
			copy = 'P';
			return 0;
		}
		break;
	case 2:
		if (i == 'q')
		{
			copy = 'R';
			return 0;
		}
		if (i == 'w')
		{
			copy = 'S';
			return 1;
		}
		if (i == 'e')
		{
			copy = 'P';
			return 0;
		}

	}
}